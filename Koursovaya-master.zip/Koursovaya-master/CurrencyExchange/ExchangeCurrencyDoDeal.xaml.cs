﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using CurrencyExchange.Classes;

namespace CurrencyExchange
{
    /// <summary>
    /// Логика взаимодействия для ExchangeCurrencyDoDeal.xaml
    /// </summary>
    public partial class ExchangeCurrencyDoDeal : Page
    {
        public ExchangeCurrencyDoDeal()
        {
            InitializeComponent();
            Currency1.ItemsSource = CurrencyExchangeEntities.GetContext().Currency.ToList();
            Currency2.ItemsSource = CurrencyExchangeEntities.GetContext().Currency.ToList();
            Currency1.SelectedValuePath = "Id_Сurrency";
            Currency1.DisplayMemberPath = "CurrencyName";
            Currency2.SelectedValuePath = "Id_Сurrency";
            Currency2.DisplayMemberPath = "CurrencyName";
        }



        private void Currency1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void Currency2_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void Button_Click_ExchangeCurr(object sender, RoutedEventArgs e)
        {
            double Currency111 = Double.Parse(Currenc1.Text);
            int current_currency1 = int.Parse(Currency1.SelectedValue.ToString());
            int current_currency2 = int.Parse(Currency2.SelectedValue.ToString());
            /*            double Currency222 = Double.Parse(Currenc2.Text);*/
            double current_sell_rate = (double)CurrencyExchangeEntities.GetContext().Currency.Where(x => x.Id_Сurrency == current_currency2).ToList()[0].SellingRate;
            double current_buy_rate = (double)CurrencyExchangeEntities.GetContext().Currency.Where(x => x.Id_Сurrency == current_currency1).ToList()[0].BuyingRate;
            double kyrsValute = current_buy_rate / current_sell_rate;
            Currenc2.Text = (Math.Round(kyrsValute * Currency111, 4)).ToString();
        }
    }
}
