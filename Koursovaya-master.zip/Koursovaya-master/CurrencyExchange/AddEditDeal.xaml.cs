﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using CurrencyExchange.Classes;

namespace CurrencyExchange
{
    /// <summary>
    /// Логика взаимодействия для AddEditDeal.xaml
    /// </summary>
    public partial class AddEditDeal : Page
    {
        private Deal _deals = new Deal();
        public AddEditDeal(Deal selectedDeal)
        {
            InitializeComponent();
            if (selectedDeal != null)
                _deals = selectedDeal;

            DataContext = _deals;
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder errors = new StringBuilder();

            if (errors.Length > 0)
            {
                MessageBox.Show(errors.ToString());
                return;
            }
            if (_deals.Id_Deal == 0)
                CurrencyExchangeEntities.GetContext().Deal.Add(_deals);

            try
            {
                CurrencyExchangeEntities.GetContext().SaveChanges();
                MessageBox.Show("Информация сохранена");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }
    }
}
