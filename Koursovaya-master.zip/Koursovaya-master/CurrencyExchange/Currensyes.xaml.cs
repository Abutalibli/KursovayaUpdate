﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using CurrencyExchange.Classes;

namespace CurrencyExchange
{
    /// <summary>
    /// Логика взаимодействия для Currensyes.xaml
    /// </summary>
    public partial class Currensyes : Page
    {
        public Currensyes()
        {
            InitializeComponent();
            DGridCurrency.ItemsSource = CurrencyExchangeEntities.GetContext().Currency.ToList();
            CmbFilterCurrency.ItemsSource = CurrencyExchangeEntities.GetContext().Currency.ToList();
            CmbFilterCurrency.SelectedValuePath = "Id_Сurrency";
            CmbFilterCurrency.DisplayMemberPath = "CurrencyName";
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new AddEditCurrencyes((sender as Button).DataContext as Currency));
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new AddEditCurrencyes(null));
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            var currencyForRemoving = DGridCurrency.SelectedItems.Cast<Currency>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить следующие {currencyForRemoving.Count()} записи?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    CurrencyExchangeEntities.GetContext().Currency.RemoveRange(currencyForRemoving);
                    CurrencyExchangeEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");
                    DGridCurrency.ItemsSource = CurrencyExchangeEntities.GetContext().Currency.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {

        }

        private void CmbFilterCurrency_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int id = Convert.ToInt32(CmbFilterCurrency.SelectedValue);
            DGridCurrency.ItemsSource = CurrencyExchangeEntities.GetContext().Currency.Where(x => x.Id_Сurrency == id).ToList();

        }

        private void SearchCurrency_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (DGridCurrency.ItemsSource != null)
            {
                DGridCurrency.ItemsSource = CurrencyExchangeEntities.GetContext().Currency.Where(x => x.CurrencyName.ToLower().Contains(SearchCurrency.Text.ToLower())).ToList();
            }
            if (SearchCurrency.Text.Count() == 0) DGridCurrency.ItemsSource = CurrencyExchangeEntities.GetContext().Currency.ToList();
        }
    }
}
