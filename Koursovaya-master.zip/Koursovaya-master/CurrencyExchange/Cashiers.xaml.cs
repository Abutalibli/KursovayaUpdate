﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using CurrencyExchange.Classes;

namespace CurrencyExchange
{
    /// <summary>
    /// Логика взаимодействия для Cashiers.xaml
    /// </summary>
    public partial class Cashiers : Page
    {
        public Cashiers()
        {
            InitializeComponent();
            DGridCashiers.ItemsSource = CurrencyExchangeEntities.GetContext().Cashier.ToList();
            CmbFilterCashier.ItemsSource = CurrencyExchangeEntities.GetContext().Cashier.ToList();
            CmbFilterCashier.SelectedValuePath = "Id_Сashier";
            CmbFilterCashier.DisplayMemberPath = "FIO";


        }
        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {

        }
        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            var cashierForRemoving = DGridCashiers.SelectedItems.Cast<Cashier>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить следующие {cashierForRemoving.Count()} записи?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    CurrencyExchangeEntities.GetContext().Cashier.RemoveRange(cashierForRemoving);
                    CurrencyExchangeEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");
                    DGridCashiers.ItemsSource = CurrencyExchangeEntities.GetContext().Cashier.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }
        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new AddEditCashier(null));
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new AddEditCashier((sender as Button).DataContext as Cashier));
        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (Visibility == Visibility.Visible)
            {
                CurrencyExchangeEntities.GetContext().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
                DGridCashiers.ItemsSource = CurrencyExchangeEntities.GetContext().Cashier.ToList();
            }
        }

        private void CmbFilterCashier_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int id = Convert.ToInt32(CmbFilterCashier.SelectedValue);
            DGridCashiers.ItemsSource = CurrencyExchangeEntities.GetContext().Cashier.Where(x => x.Id_Сashier == id).ToList();
        }

        private void SearchCashier_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (DGridCashiers.ItemsSource != null)
            {
                DGridCashiers.ItemsSource = CurrencyExchangeEntities.GetContext().Cashier.Where(x => x.FIO.ToLower().Contains(SearchCashier.Text.ToLower())).ToList();
            }
            if (SearchCashier.Text.Count() == 0) DGridCashiers.ItemsSource = CurrencyExchangeEntities.GetContext().Cashier.ToList();
        }
    }
}
