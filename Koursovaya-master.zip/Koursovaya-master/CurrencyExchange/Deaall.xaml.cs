﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using CurrencyExchange.Classes;

namespace CurrencyExchange
{
    /// <summary>
    /// Логика взаимодействия для Deaall.xaml
    /// </summary>
    public partial class Deaall : Page
    {
        public Deaall()
        {
            InitializeComponent();
            DGridDeall.ItemsSource = CurrencyExchangeEntities.GetContext().Deal.ToList();
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new AddEditDeal(null));
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            var dealForRemoving = DGridDeall.SelectedItems.Cast<Deal>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить следующие {dealForRemoving.Count()} записи?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    CurrencyExchangeEntities.GetContext().Deal.RemoveRange(dealForRemoving);
                    CurrencyExchangeEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");
                    DGridDeall.ItemsSource = CurrencyExchangeEntities.GetContext().Currency.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new AddEditDeal((sender as Button).DataContext as Deal));
        }
    }
}
