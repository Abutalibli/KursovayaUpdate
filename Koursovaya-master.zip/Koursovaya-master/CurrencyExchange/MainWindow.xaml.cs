﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using CurrencyExchange.Classes;

namespace CurrencyExchange
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            ClassFrame.frmObj = FrmCurExc;
        }

        private void Button_Click_Klient(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new Clients());
        }

        private void Button_Click_Cashier(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new Cashiers());
        }

        private void Button_Click_Currency(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new Currensyes());
        }

        private void Button_Click_ExchangeCurrency(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new Deaall());
        }

        private void Button_Click_ExchangeValueee(object sender, RoutedEventArgs e) 
        {
            ClassFrame.frmObj.Navigate(new ExchangeCurrencyDoDeal());
        }

    }
}
