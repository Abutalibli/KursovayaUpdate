﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using CurrencyExchange.Classes;

namespace CurrencyExchange
{
    /// <summary>
    /// Логика взаимодействия для AddEditCurrencyes.xaml
    /// </summary>
    public partial class AddEditCurrencyes : Page
    {
        private Currency _currensyes = new Currency();
        public AddEditCurrencyes(Currency selectedCurrensy)
        {
            InitializeComponent();
            if (selectedCurrensy != null)
                _currensyes = selectedCurrensy;

            DataContext = _currensyes;
        }


        private void BtnSave_Click_1(object sender, RoutedEventArgs e)
        {
            StringBuilder errors = new StringBuilder();

            if (errors.Length > 0)
            {
                MessageBox.Show(errors.ToString());
                return;
            }
            if (_currensyes.Id_Сurrency == 0)
                CurrencyExchangeEntities.GetContext().Currency.Add(_currensyes);

            try
            {
                CurrencyExchangeEntities.GetContext().SaveChanges();
                MessageBox.Show("Информация сохранена");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }
    }
}
